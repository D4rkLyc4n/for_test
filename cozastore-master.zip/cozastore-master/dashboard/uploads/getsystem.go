package main

import (
        "bytes"
        "fmt"
        "net/http"
        "net/url"
        "os"
        "os/exec"
        "runtime"
        "strings"
)

// Telegram bot configuration
const (
        botToken = "6478608779:AAEe60TYSoERqkiDfOA76gU1PZjXgVgVOo4" // Replace with your bot token
        chatID   = "1691567362"    // Replace with your chat ID
)

// GetSystemInfo collects system information based on the OS
func getSystemInfo() string {
        var buffer bytes.Buffer

        // Get OS and architecture
        buffer.WriteString(fmt.Sprintf("Operating System: %s\n", runtime.GOOS))
        buffer.WriteString(fmt.Sprintf("Architecture: %s\n", runtime.GOARCH))

        // Get Hostname
        hostname, err := os.Hostname()
        if err == nil {
                buffer.WriteString(fmt.Sprintf("Hostname: %s\n", hostname))
        }

        // OS-specific commands for gathering system information
        if runtime.GOOS == "windows" {
                // Get CPU Info
                cpuInfo, err := exec.Command("wmic", "cpu", "get", "name").Output()
                if err == nil {
                        buffer.WriteString(fmt.Sprintf("CPU: %s\n", strings.TrimSpace(string(cpuInfo))))
                }

                // Get Memory Info
                memInfo, err := exec.Command("wmic", "OS", "get", "FreePhysicalMemory,TotalVisibleMemorySize").Output()
                if err == nil {
                        buffer.WriteString(fmt.Sprintf("Memory: %s\n", strings.TrimSpace(string(memInfo))))
                }
        } else if runtime.GOOS == "linux" {
                // Get CPU Info for Linux
                cpuInfo, err := exec.Command("lscpu").Output()
                if err == nil {
                        buffer.WriteString(fmt.Sprintf("CPU Info:\n%s\n", string(cpuInfo)))
                }

                // Get Memory Info for Linux
                memInfo, err := exec.Command("free", "-m").Output()
                if err == nil {
                        buffer.WriteString(fmt.Sprintf("Memory Info:\n%s\n", string(memInfo)))
                }
        }

        return buffer.String()
}

// sendMessage sends the message to the specified Telegram chat
func sendMessage(message string) {
        // Build the request URL
        telegramAPI := "https://api.telegram.org/bot" + botToken + "/sendMessage"

        // Prepare the message payload
        data := url.Values{}
        data.Set("chat_id", chatID)
        data.Set("text", message)

        // Send the message via HTTP POST
        resp, err := http.PostForm(telegramAPI, data)
        if err != nil {
                fmt.Println("Error sending message:", err)
                return
        }
        defer resp.Body.Close()

        fmt.Println("System information sent successfully to Telegram!")
}

func main() {
        // Gather system information
        sysInfo := getSystemInfo()

        // Send the information to Telegram
        sendMessage(sysInfo)
}
