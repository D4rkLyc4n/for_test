<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: index.php");
    exit;
}

// Handle file upload
$uploadMessage = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['uploadedfile']) && $_FILES['uploadedfile']['error'] === UPLOAD_ERR_OK) {
        // Check if the file is a valid image (GIF or JPEG)
        $imageinfo = getimagesize($_FILES['uploadedfile']['tmp_name']);
        if ($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg') {
            $uploadMessage = "Sorry, we only accept GIF and JPEG images.";
        } else {
            // Set the upload directory
            $uploaddir = 'uploads/';
            if (!is_dir($uploaddir)) {
                mkdir($uploaddir, 0777, true);
            }

            // Define the upload path
            $uploadfile = $uploaddir . basename($_FILES['uploadedfile']['name']);

            // Move the uploaded file to the upload directory
            if (move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $uploadfile)) {
                $uploadMessage = "File is valid, and was successfully uploaded.";
            } else {
                $uploadMessage = "File uploading failed.";
            }
        }
    } else {
        $uploadMessage = "No file uploaded or an error occurred.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 15px;
            text-align: center;
        }

        nav {
            width: 200px;
            background-color: #333;
            position: fixed;
            height: 100%;
            top: 0;
            left: 0;
            padding-top: 20px;
        }

        nav a {
            display: block;
            color: #fff;
            text-decoration: none;
            padding: 10px;
            margin: 5px 0;
            text-align: center;
        }

        nav a:hover {
            background-color: #575757;
        }

        main {
            margin-left: 220px;
            padding: 20px;
        }

        .card {
            color: #fff;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .card .card-title {
            font-size: 24px;
            margin-bottom: 15px;
        }

        .card .card-content {
            margin-bottom: 15px;
        }

        .card-action {
            margin-top: 10px;
        }

        .upload-message {
            color: #ff4081;
            font-weight: bold;
        }
	button, input {
            padding: 10px;
            background-color: red;
            color: white;
            border: none;
            cursor: pointer;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<header>
    <h1>Admin Dashboard</h1>
</header>

<nav>
    <a href="admin-dashboard.php">Dashboard</a>
    <a href="#">Manage Products</a>
    <a href="#">Upload</a>
    <a href="#">Users</a>
    <a href="#">Settings</a>
</nav>

<main>
    <h2>Welcome, <?= $_SESSION['username']; ?></h2>
    <p>This is your admin dashboard.</p>

    <div class="col s9">
        <div class="card teal lighten-1">
            <div class="card-content white-text">
                <form enctype="multipart/form-data" action="admin-dashboard.php" method="POST">
                    <input type="hidden" name="MAX_FILE_SIZE" value="100000" />
                    <input name="uploadedfile" type="file" required />
                    <input type="submit" value="Upload File" />
                </form>
            </div>

            <div class="card-action">
                <?php if ($uploadMessage != ''): ?>
                    <p class="upload-message"><?= $uploadMessage; ?></p>
                <?php endif; ?>
                <?php if (isset($uploadfile) && file_exists($uploadfile)): ?>
                    <a href="<?= $uploadfile; ?>">View Uploaded File</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Logout form -->
    <form action="logout.php" method="POST">
        <button type="submit">Logout</button>
    </form>
</main>

</body>
</html>
