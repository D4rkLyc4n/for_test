<?php
session_start();

// Ensure the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: index.php");
    exit;
}

// Specify the directory where the files will be saved
$uploadDirectory = "uploads/";

// Check if the upload directory exists; if not, create it
if (!is_dir($uploadDirectory)) {
    mkdir($uploadDirectory, 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if a file was uploaded
    if (isset($_FILES['uploadedFile']) && $_FILES['uploadedFile']['error'] === UPLOAD_ERR_OK) {
        // Get the file details
        $fileTmpPath = $_FILES['uploadedFile']['tmp_name'];
        $fileName = basename($_FILES['uploadedFile']['name']);
        $fileSize = $_FILES['uploadedFile']['size'];
        $fileType = $_FILES['uploadedFile']['type'];
        $filePath = $uploadDirectory . $fileName;

        // Move the uploaded file to the desired location
        if (move_uploaded_file($fileTmpPath, $filePath)) {
            echo "File successfully uploaded: " . $fileName;
        } else {
            echo "Error uploading the file.";
        }
    } else {
        echo "No file uploaded or an error occurred during the upload.";
    }
} else {
    echo "Invalid request method.";
}
?>
